# Ecommerce-Sales-Dashboard
Created interactive dashboard to track and analyze online sales data.
Used complex parameters to drill down in worksheet and customization using filters and slicers
Created connections, join new tables, calculations to manipulate data and enable user driven parameters foe visualizations.
Used different types of customized visualization like Bar Chart, Pie chart, Cluster Bar, Scatter Chart, Line Chart, Area Chart, Map, Slicers, etc
